import React, { useState } from 'react';
import { 
  Car, Phone, Star, Clock, Shield, MapPin, CheckCircle2, BadgeCheck, 
  Menu, X, Facebook, Instagram, MessageSquare, ChevronDown, Users, Route,
  Calendar, MessageCircle
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const stats = [
    { icon: Users, value: '+1000', label: 'عميل سعيد' },
    { icon: Route, value: '+5000', label: 'كيلومتر' },
    { icon: Calendar, value: '+500', label: 'رحلة شهرياً' },
    { icon: MessageCircle, value: '+100', label: 'تقييم إيجابي' },
  ];

  const testimonials = [
    {
      name: 'أحمد محمد',
      comment: 'خدمة ممتازة وسائق محترف. سأستخدم الخدمة مرة أخرى بالتأكيد.',
      rating: 5,
    },
    {
      name: 'عبدالله علي',
      comment: 'سائق ملتزم بالمواعيد ومحترم جداً. أنصح بالتعامل معه.',
      rating: 5,
    },
    {
      name: 'محمد سعيد',
      comment: 'سيارة نظيفة ومكيفة. تجربة رائعة.',
      rating: 5,
    },
  ];

  const packages = [
    {
      name: 'رحلة قصيرة',
      price: '30',
      features: ['داخل مكة المكرمة', 'مسافة حتى 10 كم', 'توصيل مريح وآمن'],
    },
    {
      name: 'رحلة متوسطة',
      price: '50',
      features: ['داخل مكة المكرمة', 'مسافة حتى 20 كم', 'توصيل مريح وآمن'],
      popular: true,
    },
    {
      name: 'رحلة طويلة',
      price: '100',
      features: ['خارج مكة المكرمة', 'مسافة حتى 50 كم', 'توصيل مريح وآمن'],
    },
  ];

  const faqs = [
    {
      question: 'هل الخدمة متوفرة على مدار الساعة؟',
      answer: 'نعم، الخدمة متوفرة 24/7 لتلبية احتياجاتكم.',
    },
    {
      question: 'هل يمكن الحجز مسبقاً؟',
      answer: 'نعم، يمكنكم الحجز مسبقاً عبر الاتصال أو الواتساب.',
    },
    {
      question: 'ما هي وسائل الدفع المتاحة؟',
      answer: 'نقبل الدفع النقدي وعبر STC Pay وApple Pay.',
    },
  ];

  return (
    <div className="min-h-screen bg-white" dir="rtl">
      {/* Navbar */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-sm shadow-sm z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Car className="w-6 h-6 text-green-600" />
              <span className="font-bold text-xl">توصيل مكة</span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-6">
              <a href="#features" className="text-gray-600 hover:text-green-600">المميزات</a>
              <a href="#prices" className="text-gray-600 hover:text-green-600">الأسعار</a>
              <a href="#testimonials" className="text-gray-600 hover:text-green-600">التقييمات</a>
              <a href="#faq" className="text-gray-600 hover:text-green-600">الأسئلة الشائعة</a>
              <a 
                href="tel:+966500000000"
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
              >
                اتصل الآن
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container mx-auto px-4 py-4">
              <div className="flex flex-col gap-4">
                <a href="#features" className="text-gray-600">المميزات</a>
                <a href="#prices" className="text-gray-600">الأسعار</a>
                <a href="#testimonials" className="text-gray-600">التقييمات</a>
                <a href="#faq" className="text-gray-600">الأسئلة الشائعة</a>
                <a 
                  href="tel:+966500000000"
                  className="bg-green-600 text-white px-4 py-2 rounded-lg text-center"
                >
                  اتصل الآن
                </a>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <header className="relative h-[80vh] bg-gradient-to-r from-green-600 to-green-700 text-white pt-16">
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative container mx-auto px-4 h-full flex items-center">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-4 bg-white/10 w-fit px-4 py-2 rounded-full">
              <BadgeCheck className="w-5 h-5" />
              <span className="text-sm">سائق مرخص ومعتمد</span>
            </div>
            <h1 className="text-5xl font-bold mb-4">خدمة توصيل موثوقة في مكة المكرمة</h1>
            <p className="text-xl mb-8 text-gray-100">سائق شاب موثوق به يقدم خدمة توصيل آمنة ومريحة بأسعار معقولة</p>
            <div className="flex gap-4 items-center flex-wrap">
              <a 
                href="tel:+966500000000" 
                className="inline-flex items-center bg-white text-green-700 px-8 py-4 rounded-lg font-bold text-lg hover:bg-green-50 transition-colors"
              >
                <Phone className="ml-2" />
                احجز رحلتك الآن
              </a>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg">
                <div className="flex -space-x-2 space-x-reverse">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full bg-green-100 border-2 border-white flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                    </div>
                  ))}
                </div>
                <span className="text-sm">+1000 رحلة ناجحة</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Stats Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                  <stat.icon className="w-6 h-6 text-green-600" />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">لماذا تختارني؟</h2>
          <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">أقدم خدمة توصيل احترافية تجمع بين الأمان والراحة والموثوقية</p>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">خدمة آمنة وموثوقة</h3>
              <p className="text-gray-600">سائق مرخص بالكامل مع سجل قيادة ممتاز وتقييمات عالية من العملاء</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-md text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Clock className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">متوفر 24/7</h3>
              <p className="text-gray-600">خدمة على مدار الساعة طوال أيام الأسبوع لتلبية احتياجاتكم</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-md text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Car className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">سيارة حديثة ومريحة</h3>
              <p className="text-gray-600">تويوتا يارس نظيفة ومكيفة بالكامل لرحلة مريحة</p>
            </div>
          </div>
        </div>
      </section>

      {/* Car Images */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">سيارتي</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <img 
              src="https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800"
              alt="تويوتا يارس"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow w-full h-64 object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800"
              alt="تويوتا يارس من الداخل"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow w-full h-64 object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800"
              alt="تويوتا يارس من الخلف"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow w-full h-64 object-cover"
            />
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="prices" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">الأسعار والباقات</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <div 
                key={index}
                className={`bg-white rounded-xl shadow-md p-8 relative ${
                  pkg.popular ? 'border-2 border-green-500' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-4 right-1/2 transform translate-x-1/2 bg-green-500 text-white px-4 py-1 rounded-full text-sm">
                    الأكثر طلباً
                  </div>
                )}
                <h3 className="text-xl font-bold mb-4 text-center">{pkg.name}</h3>
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold">{pkg.price}</span>
                  <span className="text-gray-600"> ريال</span>
                </div>
                <ul className="space-y-3">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="tel:+966500000000"
                  className={`mt-8 block text-center py-2 rounded-lg ${
                    pkg.popular
                      ? 'bg-green-500 text-white hover:bg-green-600'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  } transition-colors`}
                >
                  احجز الآن
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">آراء العملاء</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-xl">
                <div className="flex items-center gap-2 text-yellow-400 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} fill="currentColor" className="w-5 h-5" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">{testimonial.comment}</p>
                <p className="font-bold">{testimonial.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">الأسئلة الشائعة</h2>
          <div className="max-w-3xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <details key={index} className="bg-white rounded-lg shadow-md p-6 group">
                <summary className="flex items-center justify-between cursor-pointer">
                  <span className="font-bold">{faq.question}</span>
                  <ChevronDown className="w-5 h-5 transform group-open:rotate-180 transition-transform" />
                </summary>
                <p className="mt-4 text-gray-600">{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="bg-gradient-to-br from-green-700 to-green-800 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-8">احجز رحلتك الآن</h2>
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-3 bg-white/10 px-6 py-4 rounded-lg hover:bg-white/20 transition-colors">
              <Phone className="w-6 h-6" />
              <a href="tel:+966500000000" className="text-2xl hover:underline">+966 50 000 0000</a>
            </div>
            <div className="flex items-center gap-3">
              <MapPin className="w-6 h-6" />
              <span className="text-xl">مكة المكرمة، المملكة العربية السعودية</span>
            </div>
            <div className="flex gap-4 mt-4">
              <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-white/20 transition-colors">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-white/20 transition-colors">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-white/20 transition-colors">
                <MessageSquare className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>© {new Date().getFullYear()} جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}

export default App;